package application.control;


import java.util.Collections;

import application.model.Consultor;
import application.model.Paciente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import com.google.gson.*;


public class ControladorRegistroC {
	
	Gson gson = new Gson();

    @FXML
    private Button botonSalir;

    @FXML
    private TextField miNombreC;

    @FXML
    private TextField miApellidoC;

    @FXML
    private TextField miDNIC;
    
    @FXML
    private TextField miPasswordC;

    @FXML
    private TextField miCorreoC;

    @FXML
    private Button botonVolverC;

    @FXML
    void crearConsultor(ActionEvent event) {
    
   // ObservableList<Consultor> consultores = FXCollections.observableArrayList();

    String dni = this.miDNIC.getText();
    String nombre = this.miNombreC.getText();
    String apellidos = this.miApellidoC.getText();
    String correo = this.miCorreoC.getText();
    String password = this.miPasswordC.getText();
    
    Consultor  c = new Consultor(dni, nombre, apellidos, correo, password);
    
   String json = gson.toJson(c);
   
   JsonParser parser = new JsonParser();

    }

    @FXML
    void botonSalir(ActionEvent event) {

    }

}
