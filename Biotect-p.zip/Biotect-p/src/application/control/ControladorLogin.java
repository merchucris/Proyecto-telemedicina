package application.control;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import application.model.Administrador;
import application.model.Consultor;
import application.model.Medico;
import application.model.Paciente;
import application.model.Usuario;
import javafx.animation.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
// import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ControladorLogin {
    @FXML
    private TextField etiquetauser;

    @FXML
    private PasswordField etiquetaPassword;

    @FXML
    private Button botonEntrar;

    @FXML
    private Button botonRegistro;

    @FXML
    void entrarLogin(ActionEvent event) {

    	String user = etiquetauser.getText();
    	String password = etiquetaPassword.getText();

    	ControladorLogin myJson = new ControladorLogin();

    	try {
        	Administrador[] adms = myJson.leerJsonAdministradores("admin.json");
    	    comprobarAdministrador(event, adms, user, password);
    	    
        	Paciente[] pacs = myJson.leerJsonPacientes("pacientes.json");
    	    comprobarPaciente(event, pacs, user, password);
    	    
    	    Medico[] meds = myJson.leerJsonMedicos("medicos.json");
    	    comprobarMedico(event, meds, user, password);

    	    
    	    Consultor[] consts = myJson.leerJsonConsultores("consultores.json");
    	    comprobarConsultor(event, consts, user, password);
    	 
    	    usuarioNoValido();

    	}catch (Exception e) {
    		System.out.println("*** Fallo en: "+e);
		}
    }

	void comprobarAdministrador(ActionEvent event, Administrador[] adms, String user, String password) {
		try {
			for (Administrador adm : adms ) {
				if (adm.getUsuario().equals(user) && adm.getPassword().equals(password)) {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/AdminRegistra.fxml"));
					ControladorRegistro ControlRegistro = new ControladorRegistro();
					loader.setController(ControlRegistro);
					Parent root = loader.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.initModality(Modality.WINDOW_MODAL);
					stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
					stage.show();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	void comprobarPaciente(ActionEvent event, Paciente[] pacs, String user, String password) {
		System.out.println("---DENTRO-*****--");
		try {
			for (Paciente pac : pacs ) {
				if (pac.getUsuario().equals(user) && pac.getPassword().equals(password)) {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/MenuPaciente.fxml"));
					ControladorMenuPaciente ControladorMenuPaciente = new ControladorMenuPaciente();
					loader.setController(ControladorMenuPaciente);
					Parent root = loader.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.initModality(Modality.WINDOW_MODAL);
					//stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
					stage.show();
		    		Stage myStage = (Stage) this.botonEntrar.getScene().getWindow();
		    		myStage.close();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	void comprobarMedico(ActionEvent event, Medico[] meds, String user, String password) {
		System.out.println("---DENTRO-*****--");
		try {
			for (Medico med : meds ) {
				if (med.getUsuario().equals(user) && med.getPassword().equals(password)) {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/MenuMedico.fxml"));
					ControladorMenuMedico ControladorMenuMedico = new ControladorMenuMedico();
					loader.setController(ControladorMenuMedico);
					Parent root = loader.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.initModality(Modality.WINDOW_MODAL);
					//stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
					stage.show();
					Stage myStage = (Stage) this.botonEntrar.getScene().getWindow();
					myStage.close();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	void comprobarConsultor(ActionEvent event, Consultor[] consts, String user, String password) {
		System.out.println("---DENTRO-*****--");
		try {
			for (Consultor cons : consts) {
				if (cons.getUsuario().equals(user) && cons.getPassword().equals(password)) {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/MenuConsultor.fxml"));
					ControladorMenuConsultor ControladorMenuConsultor = new ControladorMenuConsultor();
					loader.setController(ControladorMenuConsultor);
					Parent root = loader.load();
					Stage stage = new Stage();
					stage.setScene(new Scene(root));
					stage.initModality(Modality.WINDOW_MODAL);
					//stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
					stage.show();
					Stage myStage = (Stage) this.botonEntrar.getScene().getWindow();
					myStage.close();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	void usuarioNoValido() {
		etiquetauser.setText("Usuario/contrase�a no v�lida.");
		PauseTransition pause = new PauseTransition();
		pause.setDuration(Duration.seconds(2));
		pause.setOnFinished(e -> etiquetauser.setText(null));
		pause.play();
		//Alert alert = new Alert(Alert.AlertType.ERROR);
		//alert.setContentText("Usuario/contrase�a no v�lida.");
		//alert.show();
		System.out.println("Usuario/contrase�a no v�lida.");
	}
	
    Administrador[] leerJsonAdministradores(String sFile) throws java.io.IOException {
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader(sFile);
        JsonArray admins = parser.parse(fr).getAsJsonArray();
        System.out.println(admins);
        dumpJSONElement(admins);
        Gson gson = new Gson();
        Administrador[] administradores = gson.fromJson(admins, Administrador[].class);
        System.out.println("------");
        System.out.println(administradores);
        return administradores;
    }

    Paciente[] leerJsonPacientes(String sFile) throws java.io.IOException {
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader(sFile);
        System.out.println("-*-----");
        System.out.println(sFile);
        JsonArray pacs = parser.parse(fr).getAsJsonArray();
        System.out.println(pacs);
        dumpJSONElement(pacs);
        Gson gson = new Gson();
        Paciente[] pacientes = gson.fromJson(pacs, Paciente[].class);
        System.out.println("------");
        System.out.println(pacientes);
        return pacientes;
    }
    
    Medico[] leerJsonMedicos(String sFile) throws java.io.IOException {
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader(sFile);
        System.out.println("-*-----");
        System.out.println(sFile);
        JsonArray meds = parser.parse(fr).getAsJsonArray();
        System.out.println(meds);
        dumpJSONElement(meds);
        Gson gson = new Gson();
        Medico[] medicos = gson.fromJson(meds, Medico[].class);
        System.out.println("------");
        System.out.println(medicos);
        return medicos;
    }
    
    Consultor[] leerJsonConsultores(String sFile) throws java.io.IOException {
		JsonParser parser = new JsonParser();
        FileReader fr = new FileReader(sFile);
        System.out.println("-*-----");
        System.out.println(sFile);
        JsonArray consts = parser.parse(fr).getAsJsonArray();
        System.out.println(consts);
        dumpJSONElement(consts);
        Gson gson = new Gson();
        Consultor[] consultores = gson.fromJson(consts, Consultor[].class);
        System.out.println("------");
        System.out.println(consultores);
        return consultores;
    }

    void dumpJSONElement(JsonElement elemento) {
        if (elemento.isJsonObject()) {
            System.out.println("Es objeto");
            JsonObject obj = elemento.getAsJsonObject();
            java.util.Set<java.util.Map.Entry<String,JsonElement>> entradas = obj.entrySet();
            java.util.Iterator<java.util.Map.Entry<String,JsonElement>> iter = entradas.iterator();
            while (iter.hasNext()) {
                java.util.Map.Entry<String,JsonElement> entrada = iter.next();
                System.out.println("Clave: " + entrada.getKey());
                System.out.println("Valor: ");
                dumpJSONElement(entrada.getValue());
            }

        } else if (elemento.isJsonArray()) {
            JsonArray array = elemento.getAsJsonArray();
            System.out.println("Es array. Numero de elementos: " + array.size());
            java.util.Iterator<JsonElement> iter = array.iterator();
            while (iter.hasNext()) {
                JsonElement entrada = iter.next();
                dumpJSONElement(entrada);
            }

        } else if (elemento.isJsonPrimitive()) {
            System.out.println("Es primitiva");
            JsonPrimitive valor = elemento.getAsJsonPrimitive();
            if (valor.isBoolean()) {
                System.out.println("Es booleano: " + valor.getAsBoolean());
            } else if (valor.isNumber()) {
                System.out.println("Es numero: " + valor.getAsNumber());
            } else if (valor.isString()) {
                System.out.println("Es texto: " + valor.getAsString());
            }
        } else if (elemento.isJsonNull()) {
            System.out.println("Es NULL");
        } else {
            System.out.println("Es otra cosa");
        }

    }

	public static Usuario comprobarUsuario(String nombreUsuario, String password, String tipo) {

		Usuario persona = new Usuario(nombreUsuario, password, tipo);
		ObjectMapper mapper = new ObjectMapper();

		try {
		    Usuario[] usuario = mapper.readValue(new File("usuarios.json"), Usuario[].class);

		       for (int i = 0; i<=usuario.length-1; i++) {
		          if (nombreUsuario.equals((usuario[i].getUsuario()))){
		            if(password.equals(usuario[i].getPassword())) {
		              persona = usuario[i];
		              return persona;
		            }
		          }
		       }
	    } catch (JsonParseException e) {
	          	e.printStackTrace();
		} catch (JsonMappingException e) {
	         	e.printStackTrace();
	    } catch (IOException e) {
		        e.printStackTrace();
   	    }
		return null;
	}
}
