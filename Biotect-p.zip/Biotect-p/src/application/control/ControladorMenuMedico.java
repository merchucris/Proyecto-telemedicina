package application.control;

import com.jfoenix.controls.JFXTextArea;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ControladorMenuMedico {

    @FXML
    private JFXTextArea panelVisualizarM;

    @FXML
    private Button botonPerfilM;

    @FXML
    private Button botonConsultarPaciente;

    @FXML
    private Button botonVerDatosP;

    @FXML
    private Button Citas;

    @FXML
    private Button botonSalirM;

    @FXML
    void salirM(ActionEvent event) {

    }

    @FXML
    void verListaPacientes(ActionEvent event) {

    }

    @FXML
    void verPerfilM(ActionEvent event) {

    }

    @FXML
    void visualizarDatos(ActionEvent event) {

    }

}