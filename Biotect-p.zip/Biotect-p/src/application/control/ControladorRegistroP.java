package application.control;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ControladorRegistroP {

    @FXML
    private Button botonSalir;

    @FXML
    private TextField botonNombreP;

    @FXML
    private TextField botonApellidoP;

    @FXML
    private TextField botonDNIP;

    @FXML
    private TextField botonEdadP;

    @FXML
    private TextField botonCorreoP;

    @FXML
    private TextField botonDNImedicoP;

    @FXML
    private TextField botonSexoP;

    @FXML
    private Button botonCrearP;

    @FXML
    void CrearPaciente(ActionEvent event) {

    }

    @FXML
    void SalirP(ActionEvent event) {

    }

}
