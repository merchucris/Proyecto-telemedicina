package application.control;

import com.jfoenix.controls.JFXTextArea;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControladorMenuConsultor {

    @FXML
    private JFXTextArea panelVisualizarOpcionC;

    @FXML
    private Button botonPerfilC;

    @FXML
    private Button botonListaPacientes;

    @FXML
    private Button botonVerDatosC;

    @FXML
    private Button botonSalirC;

    @FXML
    void verPerfilC(ActionEvent event) {
//    	FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/.fxml"));
//		ControladorPerfilC ControladorPerfilPaciente = new ControladorPerfilC();
//		loader.setController(ControladorPerfilPaciente);
//		Parent root = loader.load();
//		Stage stage = new Stage();
//		stage.setScene(new Scene(root));
//		stage.initModality(Modality.WINDOW_MODAL);
//		stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
//		stage.show();
//		Stage myStage = (Stage) this.botonPerfilP.getScene().getWindow();
//		myStage.close();
//		

    }

    @FXML
    void abrirLista(ActionEvent event) {

    }

    @FXML
    void salirC(ActionEvent event) {

    }

    @FXML
    void verDatosSensoresC(ActionEvent event) {

    }

    @FXML
    void verListaPacientes(ActionEvent event) {

    }

}