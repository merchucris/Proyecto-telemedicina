package application.control;

public class ControladorRegistroM {

}
