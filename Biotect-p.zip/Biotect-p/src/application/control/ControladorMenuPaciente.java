package application.control;

import java.io.IOException;

import com.jfoenix.controls.JFXTextArea;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControladorMenuPaciente {

    @FXML
    private JFXTextArea panelVisualizarP;

    @FXML
    private Button botonPerfilP;

    @FXML
    private Button botonConsultarMedico;

    @FXML
    private Button botonVerDatos;

    @FXML
    private Button BotonSalirP;

    @FXML
    void consultarMedico(ActionEvent event) {

    }

    @FXML
    void salirP(ActionEvent event) {

    }

    @FXML
    void verPerfilP(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/PerfilPaciente.fxml"));
			ControladorPerfilP ControladorPerfilPaciente = new ControladorPerfilP();
			loader.setController(ControladorPerfilPaciente);
			Parent root = loader.load();
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.initModality(Modality.WINDOW_MODAL);
			//stage.initOwner(((Node) (event.getSource())).getScene().getWindow());
			stage.show();
			Stage myStage = (Stage) this.botonPerfilP.getScene().getWindow();
			myStage.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void visualizarDatosP(ActionEvent event) {

    }

}
