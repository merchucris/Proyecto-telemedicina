package repo;

import application.model.Consultor;

import java.util.List;

// Base de datos en JSON
public interface Bd {

    // A�adir un nuevo consultor
    boolean altaConsultor(Consultor consultor);

    // Recuperar un consultor por su dni
    Consultor recuperarConsultor(String dni);

    // Recuperar todos los consultores
    List<Consultor> recuperarConsultores();

    // Modificar un consultor por su dni (El registro se sabe que existe)
    boolean modificarConsultor(String dni, Consultor consultor);
    
    // Eliminar un consultor por su dni
    boolean eliminarConsultor(String dni);
}
