package repo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import application.model.Consultor;


import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

//Implementaci�n del repositorio para almacenamiento en JSON
public class JsonBD implements Bd {

    // Ruta a los datos en JSON
    private static final String RUTA_BASE_BD = "/";

    // Fichero JSON de consultores
    private static final String FICHERO_BD_CONSULTORES = "consultores.json";

    // Lista de consultores
    private List<Consultor> consultores;
    
    // Conversor de archivos JSON en objetos Java y viceversa
    Gson gson = new Gson();

    //Constructor
    public JsonBD() {
        // Depurar
        System.out.println("Creando clase GSON de Google para persistencia en JSON...");

        // Creando clase GSON de Google para persistencia en JSON
        this.gson = new Gson();

        // Depurar
        System.out.println("Creada clase GSON de Google para persistencia en JSON -> OK");

        this.consultores = recuperarListaConsultores();
    }

	// Modificar un consultor por su dni (recuperar consultores + borrar consultor + a�adir consultor modificado)
	@Override
	public boolean modificarConsultor(String dni, Consultor consultor) {
        //Para depurar
        System.out.println("Recuperar consultores...");
        List<Consultor> consultores = recuperarConsultores();
        System.out.println("Eliminar consultor antes de a�adir el consultor actualizado");
        consultores.remove(consultor);
        eliminarConsultor(dni);
        System.out.println("A�adir consultor...");
        consultores.add(consultor);
        //Para depurar
        System.out.println("Listo para guardar el consultor modificado");
        // Guardar los consultores
        guardarConsultores();
        //Para depurar
        System.out.println("Consultor modificado (guardado) [" + consultor.getDni() + "] OK");

		return false;
	}

	// Recuperar el listado de usuarios del JSON como objetos Java
    private List<Consultor> recuperarListaConsultores() {
        //Depurar
        System.out.println("Obteniendo listado de usuarios desde la persistencia JSON...");
        System.out.println(FICHERO_BD_CONSULTORES);

        String consultorJSON = recuperarJSONString(FICHERO_BD_CONSULTORES);
        final Type tipoListaConsultor = new TypeToken<List<Consultor>>(){}.getType();
        return gson.fromJson(consultorJSON, tipoListaConsultor);
    }

    // Recuperar el contenido de un fichero JSON del almacenamiento como String
    private String recuperarJSONString(String nombreFichero) {
        String dataString = null;
        try {
            File fichero = new File(getClass().getResource(RUTA_BASE_BD + nombreFichero).getFile());
            BufferedReader reader = new BufferedReader(new FileReader(fichero));
            StringBuilder strBuilder = new StringBuilder();
            String linea;
            while ((linea = reader.readLine()) != null) {
                strBuilder.append(linea);
            }
            reader.close();
            dataString = strBuilder.toString();
        } catch (IOException e) {
            System.out.println("Error al recuperar del fichero "+nombreFichero+" la lista de JSON: " + e.getMessage());
            //e.printStackTrace();
        }
        return dataString;
    }

    // Guardar el JSON de consultores
    private void guardarConsultores() {
        String json = gson.toJson(this.consultores);
        File file = new File(getClass().getResource(RUTA_BASE_BD + FICHERO_BD_CONSULTORES).getFile());
        guardarJSONFichero(json,file);
    }

    //Escribir un JSON en el fichero especificado
    private void guardarJSONFichero(String json, File fichero) {
        try {
            FileWriter writer = new FileWriter(fichero);
            writer.write(json);
            writer.close();
        } catch (IOException e) {
            System.out.println("Error al guardar en JSON: " + e.getMessage());
            //e.printStackTrace();
        }
    }

    // Recuperar un consultor por su dni
    private Consultor recuperarConsultorPorDni(String dni) {
        //Para depurar
        System.out.println("Buscando consultor [" + dni + "]...");

        if  (consultores != null) {
            for (Consultor consultorBusqueda : consultores) {
                if (consultorBusqueda.getDni().equals(dni)) {
                    System.out.println("Consultor encontrado [" + dni + "] -> OK");
                    return consultorBusqueda;
                }
            }
        } 
       	//Si no se ha encontrado el usuario
       	System.out.println("No se ha encontrado el consultor [" + dni + "]");
       	return null;

    }

    // A�adir un nuevo consultor
    @Override
    public boolean altaConsultor(Consultor consultor) {
        // No debe ya haber un consultor
        if (recuperarConsultorPorDni(consultor.getDni()) != null) {
            //Para depurar
            System.out.println("El consultor [" + consultor.getDni() + "] ya existe...");

            return false;
        }

        //Para depurar
        System.out.println("Dando de alta consultor [" + consultor.getDni() + "]...");
        //Agregamos el usuario a la lista de objetos de usuarios Java
        consultores.add(consultor);
        //Para depurar
        System.out.println("Listo para dar de alta al consultor [" + consultor.getDni() + "]");
        // Guardar los consultores
        guardarConsultores();

        //Para depurar
        System.out.println("Consultor dado de alta (guardado) [" + consultor.getDni() + "] OK");

        return true;
    }

    // Recuperar un consultor por su dni
    @Override
    public Consultor recuperarConsultor(String dni) {
        return recuperarConsultorPorDni(dni);
    }

    // Recuperar todos los consultores
    @Override
    public List<Consultor> recuperarConsultores() {
        return consultores;
    }

    // Eliminar un consultor por su dni
    @Override
    public boolean eliminarConsultor(String dni) {
        //Para depurar
        System.out.println("Eliminando consultor [" + dni + "]...");

        Consultor consultor = recuperarConsultorPorDni(dni);
        if (consultor == null)
            return false;
        consultores.remove(consultor);

        //Para depurar
        System.out.println("Consultor eliminado [" + dni + "]");

        return true;
    }

}